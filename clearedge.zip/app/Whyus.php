<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Whyus extends Model
{
    protected $fillable = ['heading', 'p1', 'p2', 'p3'];
}
