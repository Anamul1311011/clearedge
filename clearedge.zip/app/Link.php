<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{
    protected $fillable = ['title1', 'title2', 'title3', 'title4', 'title5'];
}
