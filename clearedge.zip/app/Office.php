<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Office extends Model
{
    protected $fillable = ['heading', 'title1', 'title2', 'title3', 'title4', 'title5', 'title6', 'title7', 'title8','title9', 'title10', 'title11', 'title12', 'title13', 'title14', 'title15', 'title16', 'title17'];
}
