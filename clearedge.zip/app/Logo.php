<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Logo extends Model
{
    protected $fillable = ['para', 'tel1', 'tel2', 'logo_image'];
}
