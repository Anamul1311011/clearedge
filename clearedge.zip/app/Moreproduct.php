<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Moreproduct extends Model
{
      protected $fillable = ['title', 'detail', 'mproduct_image'];
}
