<?php $__env->startSection('add-logo-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/logo')); ?>">
        Add Logo
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Logos</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Logos
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/logo')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Logo Para</label>
                  <input type="hidden" name="logo_id" value="<?php echo e($logo->id); ?>">
                  <input type="text" class="form-control" placeholder="Enter logo para" name="para" value="<?php echo e($logo->para); ?>">
                </div>
                <div class="form-group">
                  <label>Logo Tel1</label>
                  <input type="text" class="form-control" placeholder="Enter logo Tel1" name="tel1" value="<?php echo e($logo->tel1); ?>">
                </div>
                <div class="form-group">
                  <label>Logo Tel2</label>
                  <input type="text" class="form-control" placeholder="Enter logo Tel2" name="tel2" value="<?php echo e($logo->tel2); ?>">
                </div>
                <div class="form-group">
                  <label>Logo Image</label>
                  <input type="file" class="form-control" placeholder="Enter logo Image" name="logo_image" value="<?php echo e($logo->logo_image); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update logos</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/logo/edit.blade.php ENDPATH**/ ?>