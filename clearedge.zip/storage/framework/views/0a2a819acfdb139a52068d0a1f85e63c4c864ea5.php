<?php $__env->startSection('add-whyus-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Whyus</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Whyus</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              <?php if(session('successdelete')): ?>
                                <div class="alert alert-info">
                                    <?php echo e(session('successdelete')); ?>

                                </div>
                                <?php endif; ?>

               Whyus List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>Whyus heading</th>
                  <th>Whyus p1</th>
                  <th>Whyus p2</th>
                  <th>Whyus p3</th>
                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            <?php $__currentLoopData = $whyuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whyus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($whyus->heading); ?></td>
                <td><?php echo e($whyus->p1); ?></td>
                <td><?php echo e($whyus->p2); ?></td>
                <td><?php echo e($whyus->p3); ?></td>
                <td><?php echo e($whyus->created_at->format('d-m-Y H:i:s A')); ?></td>
                <td><?php echo e($whyus->updated_at ? $whyus->updated_at:"Not Yet"); ?></td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(url('delete/whyus')); ?>/<?php echo e($whyus->id); ?>"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></span> </a>
                  <a class="btn btn-info" href="<?php echo e(url('edit/whyus')); ?>/<?php echo e($whyus->id); ?>"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              Add Whyus
            </div>

            <div class="panel-body">
              <form action="<?php echo e(url('/insert/whyus')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>heading</label>
                  <input type="text" class="form-control" placeholder="Enter heading" name="heading" >
                </div>
                <div class="form-group">
                  <label>p1</label>
                  <input type="text" class="form-control" placeholder="Enter p1" name="p1" >
                </div>
                <div class="form-group">
                  <label>p2</label>
                  <input type="text" class="form-control" placeholder="Enter p2" name="p2" >
                </div>
                <div class="form-group">
                  <label>p3</label>
                  <input type="text" class="form-control" placeholder="Enter p3" name="p3" >
                </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    <?php if($errors->all()): ?>
      <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/whyus/view.blade.php ENDPATH**/ ?>