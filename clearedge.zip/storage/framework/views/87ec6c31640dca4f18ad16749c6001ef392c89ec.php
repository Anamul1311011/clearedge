<?php $__env->startSection('add-menu-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/menu')); ?>">
        Add Menu
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Menus</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Menus
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/menu')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Menu Title</label>
                  <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">
                  <input type="text" class="form-control" placeholder="Enter menu para" name="title" value="<?php echo e($menu->title); ?>">
                </div>
                <div class="form-group">
                  <label>Menu Link1</label>
                  <input type="text" class="form-control" placeholder="Enter menu link1" name="link1" value="<?php echo e($menu->link1); ?>">
                </div>
                <div class="form-group">
                  <label>Menu Link2</label>
                  <input type="text" class="form-control" placeholder="Enter menu link2" name="link2" value="<?php echo e($menu->link2); ?>">
                </div>
                <div class="form-group">
                  <label>Menu Link3</label>
                  <input type="text" class="form-control" placeholder="Enter menu link3" name="link3" value="<?php echo e($menu->link3); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Menus</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/menu/edit.blade.php ENDPATH**/ ?>