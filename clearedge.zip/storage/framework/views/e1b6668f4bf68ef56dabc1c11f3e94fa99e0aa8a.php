<?php $__env->startSection('add-sociallink-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Social Link</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Social Link</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              <?php if(session('successdelete')): ?>
                                <div class="alert alert-info">
                                    <?php echo e(session('successdelete')); ?>

                                </div>
                                <?php endif; ?>

              Social Link List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>link1</th>
                  <th>link2</th>
                  <th>link3</th>
                  <th>link4</th>

                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            <?php $__currentLoopData = $sociallinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sociallink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

                <td><?php echo e($sociallink->link1); ?></td>
                <td><?php echo e($sociallink->link2); ?></td>
                <td><?php echo e($sociallink->link3); ?></td>
                <td><?php echo e($sociallink->link4); ?></td>
                
                <td><?php echo e($sociallink->updated_at ? $link->updated_at:"Not Yet"); ?></td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(url('delete/sociallink')); ?>/<?php echo e($sociallink->id); ?>"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></i></span> </a>
                  <a class="btn btn-info" href="<?php echo e(url('edit/sociallink')); ?>/<?php echo e($sociallink->id); ?>"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              Add Social Link
            </div>

            <div class="panel-body">
              <form action="<?php echo e(url('/insert/sociallink')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Link1</label>
                  <input type="text" class="form-control" name="link1" >
                </div>
                <div class="form-group">
                  <label>Link2</label>
                  <input type="text" class="form-control" name="link2" >
                </div>
                <div class="form-group">
                  <label>Link3</label>
                  <input type="text" class="form-control" name="link3" >
                </div>
                <div class="form-group">
                  <label>Link4</label>
                  <input type="text" class="form-control" name="link4" >
                </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    <?php if($errors->all()): ?>
      <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/sociallink/view.blade.php ENDPATH**/ ?>