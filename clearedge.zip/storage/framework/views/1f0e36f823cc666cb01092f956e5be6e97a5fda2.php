<?php $__env->startSection('add-logo-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Footer</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Footer</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              <?php if(session('successdelete')): ?>
                                <div class="alert alert-info">
                                    <?php echo e(session('successdelete')); ?>

                                </div>
                                <?php endif; ?>

               Footer List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>Footer Text1</th>
                  <th>Footer text2</th>
                  <th>Footer Image</th>
                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            <?php $__currentLoopData = $footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($footer->text1); ?></td>
                <td><?php echo e($footer->text2); ?></td>
                <td><img width="100" src="<?php echo e(asset($footer->footer_image)); ?>" alt=""></td>
                <td><?php echo e($footer->created_at->format('d-m-Y H:i:s A')); ?></td>
                <td><?php echo e($footer->updated_at ? $footer->updated_at:"Not Yet"); ?></td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(url('delete/footer')); ?>/<?php echo e($footer->id); ?>"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></span> </a>
                  <a class="btn btn-info" href="<?php echo e(url('edit/footer')); ?>/<?php echo e($footer->id); ?>"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              Add Footer
            </div>

            <div class="panel-body">
              <form action="<?php echo e(url('/insert/footer')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Footer Text1</label>
                  <input type="text" class="form-control" placeholder="Enter text1" name="text1" >
                </div>
                <div class="form-group">
                  <label>Footer Text2</label>
                  <input type="text" class="form-control" placeholder="Enter text2" name="text2" >
                </div>

          <div class="form-group">
            <label>Footer Image</label>
            <input type="file" class="form-control" placeholder="Enter footer Image" name="footer_image" >
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    <?php if($errors->all()): ?>
      <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/footer/view.blade.php ENDPATH**/ ?>