<?php $__env->startSection('add-banner-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/banner')); ?>">
        Add Banner
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Banner</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Banner
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/banner')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Banner Heading</label>
                  <input type="hidden" name="banner_id" value="<?php echo e($banner->id); ?>">
                  <input type="text" class="form-control" placeholder="Enter Banner Heading" name="heading" value="<?php echo e($banner->heading); ?>">
                </div>
                <div class="form-group">
                  <label>Banner Sub-heading</label>
                  <input type="text" class="form-control" placeholder="Enter Banner Sub-Heading" name="sub_heading" value="<?php echo e($banner->sub_heading); ?>">
                </div>
                <div class="form-group">
                  <label>Banner Detials</label>
                  <input type="text" class="form-control" placeholder="Enter Banner Detail" name="details" value="<?php echo e($banner->details); ?>">
                </div>
                <div class="form-group">
                  <label>Banner Image</label>
                  <input type="file" class="form-control" placeholder="Enter banner Image" name="banner_image" value="<?php echo e($banner->banner_image); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Banners</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/banner/edit.blade.php ENDPATH**/ ?>