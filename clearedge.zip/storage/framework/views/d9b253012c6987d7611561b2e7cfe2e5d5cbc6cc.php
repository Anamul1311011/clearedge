<?php $__env->startSection('add-logo-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/logo')); ?>">
        Add Logo
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Logos</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Payments
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/payment')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Link1</label>
                  <input type="hidden" name="payment_id" value="<?php echo e($payment->id); ?>">
                  <input type="text" class="form-control" name="link1" value="<?php echo e($payment->link1); ?>">
                </div>
                <div class="form-group">
                  <label>Link2</label>
                  <input type="text" class="form-control" name="link2" value="<?php echo e($payment->link2); ?>">
                </div>
                <div class="form-group">
                  <label>Title1</label>
                  <input type="text" class="form-control" name="title1" value="<?php echo e($payment->title1); ?>">
                </div>
                <div class="form-group">
                  <label>Title2</label>
                  <input type="text" class="form-control" name="title2" value="<?php echo e($payment->title2); ?>">
                </div>
                <div class="form-group">
                  <label>Text1</label>
                  <input type="text" class="form-control" name="text1" value="<?php echo e($payment->text1); ?>">
                </div>
                <div class="form-group">
                  <label>Text2</label>
                  <input type="text" class="form-control" name="text2" value="<?php echo e($payment->text2); ?>">
                </div>
                <div class="form-group">
                  <label>Text3</label>
                  <input type="text" class="form-control" name="text3" value="<?php echo e($payment->text3); ?>">
                </div>
                <div class="form-group">
                  <label>Image1</label>
                  <input type="file" class="form-control" name="image1" value="<?php echo e($payment->image1); ?>">
                </div>
                <div class="form-group">
                  <label>Image2</label>
                  <input type="file" class="form-control" name="image2" value="<?php echo e($payment->image2); ?>">
                </div>
                <div class="form-group">
                  <label>Image3</label>
                  <input type="file" class="form-control" name="image3" value="<?php echo e($payment->image3); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Payments</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/payment/edit.blade.php ENDPATH**/ ?>