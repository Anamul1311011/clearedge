<?php $__env->startSection('add-city-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/city')); ?>">
        Add City
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit City</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit City
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/city')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Title</label>
                  <input type="hidden" name="city_id" value="<?php echo e($city->id); ?>">
                  <input type="text" class="form-control" name="title" value="<?php echo e($city->title); ?>">
                </div>
                <div class="form-group">
                  <label>Link</label>
                  <input type="text" class="form-control" name="link" value="<?php echo e($city->link); ?>">
                </div>

                <button type="submit" class="btn btn-primary">Update City</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/city/edit.blade.php ENDPATH**/ ?>