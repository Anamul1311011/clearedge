<?php $__env->startSection('add-banner-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Banner</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Banner</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              <?php if(session('successdelete')): ?>
                                <div class="alert alert-info">
                                    <?php echo e(session('successdelete')); ?>

                                </div>
                                <?php endif; ?>

               Banner List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>Banner heading</th>
                  <th>Banner sub_heading</th>
                  <th>Banner details</th>
                  <th>Banner banner_image</th>
                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($banner->heading); ?></td>
                <td><?php echo e($banner->sub_heading); ?></td>
                <td><?php echo e($banner->details); ?></td>
                <td><img width="100" src="<?php echo e(asset($banner->banner_image)); ?>" alt=""></td>
                <td><?php echo e($banner->created_at->format('d-m-Y H:i:s A')); ?></td>
                <td><?php echo e($banner->updated_at ? $banner->updated_at:"Not Yet"); ?></td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(url('delete/banner')); ?>/<?php echo e($banner->id); ?>"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></span> </a> |
                  <a class="btn btn-info" href="<?php echo e(url('edit/banner')); ?>/<?php echo e($banner->id); ?>"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              Add Banners
            </div>

            <div class="panel-body">
              <form action="<?php echo e(url('/insert/banner')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Banner Heading</label>
            <input type="text" class="form-control" placeholder="Enter banner heading" name="heading" value="<?php echo e(old('heading')); ?>">
          </div>
          <div class="form-group">
            <label>Banner sub_heading</label>
            <input type="text" class="form-control" placeholder="Enter Product Title" name="sub_heading" value="<?php echo e(old('sub_heading')); ?>">
          </div>
          <div class="form-group">
            <label>Banner Details</label>
            <input type="text" class="form-control" placeholder="Enter Product Id" name="details" value="<?php echo e(old('details')); ?>">
          </div>
          <div class="form-group">
            <label>Banner Image</label>
            <input type="file" class="form-control" placeholder="Enter banner Image" name="banner_image" >
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    <?php if($errors->all()): ?>
      <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/banner/view.blade.php ENDPATH**/ ?>