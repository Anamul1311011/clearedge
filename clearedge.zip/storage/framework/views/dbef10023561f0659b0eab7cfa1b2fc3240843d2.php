<?php $__env->startSection('add-support-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/support')); ?>">
        Add Support
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Support</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Support
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/support')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label>Heading</label>
                  <input type="hidden" name="support_id" value="<?php echo e($support->id); ?>">
                  <input type="text" class="form-control" placeholder="Enter heading" name="heading" value="<?php echo e($support->heading); ?>">
                </div>
                <div class="form-group">
                  <label>Details</label>
                  <input type="text" class="form-control" placeholder="Enter service link1" name="details" value="<?php echo e($support->details); ?>">
                </div>


                <div class="form-group">
                  <label>Image</label>
                  <input type="file" class="form-control" placeholder="Enter Image" name="image" value="<?php echo e($support->image); ?>">
                </div>

                <button type="submit" class="btn btn-primary">Update Supports</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/support/edit.blade.php ENDPATH**/ ?>