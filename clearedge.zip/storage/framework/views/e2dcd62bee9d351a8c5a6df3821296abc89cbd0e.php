<?php $__env->startSection('add-product-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Product</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Product</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              <?php if(session('successdelete')): ?>
                                <div class="alert alert-info">
                                    <?php echo e(session('successdelete')); ?>

                                </div>
                                <?php endif; ?>

               Product List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>Product Name</th>
                  <th>Product Title</th>
                  <th>Product ID</th>
                  <th>Product Detail</th>
                  <th>Product Image</th>
                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($product->product_name); ?></td>
                <td><?php echo e($product->product_title); ?></td>
                <td><?php echo e($product->product_ID); ?></td>
                <td><?php echo e($product->product_detail); ?></td>
                <td><img width="100" src="<?php echo e(asset($product->product_image)); ?>" alt=""></td>
                <td><?php echo e($product->created_at->format('d-m-Y H:i:s A')); ?></td>
                <td><?php echo e($product->updated_at ? $product->updated_at:"Not Yet"); ?></td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(url('delete/product')); ?>/<?php echo e($product->id); ?>"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></span> </a> |
                  <a class="btn btn-info" href="<?php echo e(url('edit/product')); ?>/<?php echo e($product->id); ?>"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              Add Products
            </div>

            <div class="panel-body">
              <form action="<?php echo e(url('/insert/product')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" placeholder="Enter Product Name" name="product_name" value="<?php echo e(old('product_name')); ?>">
          </div>
          <div class="form-group">
            <label>Product Title</label>
            <input type="text" class="form-control" placeholder="Enter Product Title" name="product_title" value="<?php echo e(old('product_title')); ?>">
          </div>
          <div class="form-group">
            <label>Product Id</label>
            <input type="text" class="form-control" placeholder="Enter Product Id" name="product_ID" value="<?php echo e(old('product_ID')); ?>">
          </div>
          <div class="form-group">
            <label>Product Details</label>
            <input type="text" class="form-control" placeholder="Enter Product Detail" name="product_detail" value="<?php echo e(old('product_detail')); ?>">
          </div>
          <div class="form-group">
            <label>Product Image</label>
            <input type="file" class="form-control" placeholder="Enter Product Image" name="product_image" >
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    <?php if($errors->all()): ?>
      <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/product/view.blade.php ENDPATH**/ ?>