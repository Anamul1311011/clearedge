<?php $__env->startSection('add-footer-page'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/home')); ?>">
        <em class="fa fa-home"></em>
      </a></li>
      <li><a href="<?php echo e(url('/add/footer')); ?>">
        Add Footer
      </a></li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Edit Footer</h1>
    </div>
  </div><!--/.row-->
  <div class="container">
      <div class="row justify-content-center">

          <div class="col-md-6">
              <div class="panel panel-success">
                  <div class="panel-heading">
                    <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                    <?php endif; ?>

                    Edit Footer
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo e(url('/update/footer')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Text1</label>
                  <input type="hidden" name="footer_id" value="<?php echo e($footer->id); ?>">
                  <input type="text" class="form-control" placeholder="Enter text1" name="text1" value="<?php echo e($footer->text1); ?>">
                </div>
                <div class="form-group">
                  <label>Text2</label>
                  <input type="text" class="form-control" placeholder="Enter text2" name="text2" value="<?php echo e($footer->text2); ?>">
                </div>
                <div class="form-group">
                  <label>Footer Image</label>
                  <input type="file" class="form-control" placeholder="Enter footer Image" name="footer_image" value="<?php echo e($footer->footer_image); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Footer</button>
              </form>
              <br>
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($value); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel\clearedge\resources\views/footer/edit.blade.php ENDPATH**/ ?>