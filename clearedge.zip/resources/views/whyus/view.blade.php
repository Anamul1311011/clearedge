@extends('layouts.dashboard')
@section('add-whyus-page')
  active
@endsection
@section('content')
  <div class="row">
    <ol class="breadcrumb">
      <li><a href="{{ url('/home') }}">
        <em class="fa fa-home"></em>
      </a></li>
      <li class="active">Add Whyus</li>
    </ol>
  </div><!--/.row-->

  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Add Whyus</h1>
    </div>
  </div><!--/.row-->
  <div class="panel panel-container">
    <div class="row">
      <div class="col-md-8">
        <div class="panel panel-success">
            <div class="panel-heading">
              @if(session('successdelete'))
                                <div class="alert alert-info">
                                    {{ session('successdelete') }}
                                </div>
                                @endif

               Whyus List
            </div>

            <div class="panel-body">
              <table class="table table-bordered">
                <thead>
                  <th>Whyus heading</th>
                  <th>Whyus p1</th>
                  <th>Whyus p2</th>
                  <th>Whyus p3</th>
                  <th>Created At</th>
                  <th>Last Updated At</th>
                  <th>Action</th>
                </thead>
            @foreach ($whyuses as $whyus)
              <tr>
                <td>{{ $whyus->heading }}</td>
                <td>{{ $whyus->p1 }}</td>
                <td>{{ $whyus->p2 }}</td>
                <td>{{ $whyus->p3 }}</td>
                <td>{{ $whyus->created_at->format('d-m-Y H:i:s A') }}</td>
                <td>{{ $whyus->updated_at ? $whyus->updated_at:"Not Yet" }}</td>
                <td>
                  <a class="btn btn-danger" href="{{ url('delete/whyus') }}/{{ $whyus->id }}"> <span style="color:white"><i class="fa fa-trash" aria-hidden="true"></i></span> </a>
                  <a class="btn btn-info" href="{{ url('edit/whyus') }}/{{ $whyus->id }}"> <span style="color:white"><i class="fa fa-pencil" aria-hidden="true"></i></span> </a>
                </td>
              </tr>
            @endforeach
              </table>

              </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="panel panel-info">
            <div class="panel-heading">
              @if (session('success'))
                <div class="alert alert-success">
                  {{ session('success') }}
                </div>
              @endif

              Add Whyus
            </div>

            <div class="panel-body">
              <form action="{{ url('/insert/whyus') }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                  <label>heading</label>
                  <input type="text" class="form-control" placeholder="Enter heading" name="heading" >
                </div>
                <div class="form-group">
                  <label>p1</label>
                  <input type="text" class="form-control" placeholder="Enter p1" name="p1" >
                </div>
                <div class="form-group">
                  <label>p2</label>
                  <input type="text" class="form-control" placeholder="Enter p2" name="p2" >
                </div>
                <div class="form-group">
                  <label>p3</label>
                  <input type="text" class="form-control" placeholder="Enter p3" name="p3" >
                </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
    @if ($errors->all())
      <div class="alert alert-danger">
        @foreach ($errors->all() as $value)
          <li>{{ $value }}</li>
        @endforeach
      </div>
    @endif
            </div>
        </div>
      </div>
    </div><!--/.row-->
  </div>

@endsection
